<?php

/*
Plugin Name: Miracle Custom Post
Plugin URI: http://www.soaptheme.net/wordpress/miracle/
Description: This plugin is required for miracle theme as it sets up custom post types such as portfolio.
Version: 1.0.0
Author: SoapTheme
Author URI: http://www.soaptheme.net/
Text Domain: miracle
Miracle Plugin: miracle-custom-post
*/

/**
 * Set up portfolio post type for miracle theme
 */
function miracle_portfolio_init() {

	//Load plugin textdomain.
	load_plugin_textdomain( 'miracle', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );

	$menu_icon = ( floatval( get_bloginfo( 'version' ) ) >= '3.8' ) ? 'dashicons-format-gallery' : NULL;

	// titles
	$labels = array(
		'name'                  => __('Portfolio', 'miracle'),
		'singular_name'         => __('Portfolio Item', 'miracle'),
		'add_new'               => __('Add New', 'miracle'),
		'add_new_item'          => __('Add New Portfolio Item', 'miracle'),
		'edit_item'             => __('Edit Portfolio Item', 'miracle'),
		'new_item'              => __('New Item', 'miracle'),
		'view_item'             => __('View Item', 'miracle'),
		'search_items'          => __('Search Portfolio Items', 'miracle'),
		'not_found'             => __('No Portfolio items found', 'miracle'),
		'not_found_in_trash'    => __('No Portfolio items found in Trash', 'miracle'),
		'parent_item_colon'     => '',
		'menu_name'             => __('Portfolio', 'backend portfolio', 'miracle')
	);

	// options
	$args = array(
		'labels'                => $labels,
		'public'                => true,
		'publicly_queryable'    => true,
		'show_ui'               => true,
		'show_in_menu'          => true, 
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'portfolio' ),
		'capability_type'       => 'post',
		'has_archive'           => true, 
		'hierarchical'          => false,
		'menu_position'         => 5,
		'menu_icon'       => $menu_icon,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'comments', 'excerpt', 'revisions', 'custom-fields' )
	);

	$args = apply_filters( 'miracle_portfolio_post_type_args', $args );

	register_post_type( 'm_portfolio', $args );

	// Portfolio tags taxonomy

	// titles
	$labels = array(
		'name'              => __( 'Portfolio Categories', 'miracle' ),
		'singular_name'     => __( 'Portfolio Category', 'miracle' ),
		'search_items'      => __( 'Search in Portfolio Category', 'miracle' ),
		'all_items'         => __( 'All Portfolio Categories', 'miracle' ),
		'parent_item'       => __( 'Parent Portfolio Category', 'miracle' ),
		'parent_item_colon' => __( 'Parent Portfolio Category:', 'miracle' ),
		'edit_item'         => __( 'Edit Portfolio Category', 'miracle' ), 
		'update_item'       => __( 'Update Portfolio Category', 'miracle' ),
		'add_new_item'      => __( 'Add New Portfolio Category', 'miracle' ),
		'new_item_name'     => __( 'New Portfolio Category Name', 'miracle' ),
		'menu_name'         => __( 'Portfolio Categories', 'miracle' )
	);

	$taxonomy_args = array(
		'hierarchical'          => true,
		'public'                => true,
		'labels'                => $labels,
		'show_ui'               => true,
		'rewrite'               => array('slug' => 'portfolio-category'),
		'show_admin_column'		=> true,
	);

	$taxonomy_args = apply_filters( 'miracle_taxonomy_portfolio_args', $taxonomy_args );
	register_taxonomy( 'm_portfolio_category', array( 'm_portfolio' ), $taxonomy_args );
}

add_action( 'init', 'miracle_portfolio_init' );